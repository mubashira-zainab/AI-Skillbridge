# AI SkillBridge

An AI-powered career guidance platform. Users sign up with their education,
skills, and interests, and get a personalized career match, skill gap
analysis, learning roadmap, and job recommendations.

## Structure

```
ai-skillbridge/
  frontend/     Static HTML/CSS/JS site (built by team)
  backend/      Node.js + Express + SQLite API (this contribution)
```

## Contribution

This repository contains the **backend**, built with Node.js, Express, and
SQLite, and the **connection** wiring it up to the existing frontend
(added `id` attributes for JS targeting, `api.js`, and `<script>` tags for
signup/login/dashboard/logout — no changes to the frontend's design, layout,
or content).

## Setup

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env      # then set a real JWT_SECRET
npm run seed                # populate careers & jobs reference data
npm start
```
API runs at `http://localhost:5000`.

### 2. Frontend

Open `frontend/index.html` using a local dev server (e.g. VS Code's "Live
Server" extension) — not by double-clicking the file. Cookies/auth require
the page to be served over `http://`, not opened as `file://`.

By default the frontend expects the backend at `http://localhost:5000/api`
(see `frontend/api.js`) and the backend expects the frontend to run at
`http://localhost:5500` (see `FRONTEND_URL` in `backend/.env`). Adjust either
if your ports differ.

## Try it

1. Start the backend (`npm start` inside `backend/`)
2. Open `frontend/signup.html` via Live Server
3. Create an account with some skills (e.g. `HTML, CSS, Python`)
4. You'll be redirected to `dashboard.html`, showing a real career match,
   skill gap, roadmap, and job recommendations based on what you entered —
   not hardcoded placeholder data

## Features

- Signup / login / logout with hashed passwords and JWT (httpOnly cookie)
- Dashboard driven by real data: career match %, skill gap, learning
  roadmap, and job recommendations — computed from the skills a user enters
- Rule-based recommendation engine (`backend/models/recommendationEngine.js`)

See `backend/README.md` for full API documentation.

## License

MIT
