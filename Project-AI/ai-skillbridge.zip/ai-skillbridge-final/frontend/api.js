// api.js
// Small fetch wrapper shared by all pages. Talks to the AI SkillBridge backend.
//
// Update API_BASE once the backend is deployed (e.g. to Render/Railway).
// For local development, keep it pointing at localhost.

const API_BASE = "http://localhost:5000/api";

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include", // sends the httpOnly auth cookie
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}
